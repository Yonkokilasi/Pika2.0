package com.yonko.pika.util;

import android.support.v7.widget.RecyclerView;

/**
 * Created by bubbles on 6/13/17.
 */

public interface OnStartDragListener {
    void  onStartDrag(RecyclerView.ViewHolder viewHolder);
}

