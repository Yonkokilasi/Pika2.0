package com.yonko.pika.util;

/**
 * Created by bubbles on 6/15/17.
 */

public interface ItemTouchHelperViewHolder {
    void onItemSelected();
    void onItemClear();
}
